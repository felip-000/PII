/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quilphin;

/**
 *
 * @author felip_000
 */
import java.sql.*;
public class Conexao {
    private static String host = "localhost";
    private static String porta = "3306";
    private static String db = "Quilphin";
    private static String usuario = "root";
    private static String senha = ""; //adicionar
    
    public static Connection obterConexao()throws Exception {
        String s = String.format("jdbc:mysql://%s:%s/%s", host, porta, db);
        //clausula catch or declare
        return DriverManager.getConnection(s, usuario, senha);
    }
    public static void main(String[] args) throws Exception {
        obterConexao();
    } 
}