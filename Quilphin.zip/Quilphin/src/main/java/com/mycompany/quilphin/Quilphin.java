package com.mycompany.quilphin;
public class Quilphin {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
