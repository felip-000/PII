create database jogo; 
use jogo; 
create table Questao ( 
	id int not null auto_increment, 
    alternativa1 varchar (400) not null, 
    alternativa2 varchar (400) not null, 
    alternativa3 varchar (400) not null, 
    alternativa4 varchar (400) not null, 
    Pergunta varchar (400) not null, 
    Resposta varchar (400) not null, 
    Pontos int not null, 
    primary key (id)); 

create table Usuario ( 
	RA char(10) not null, 
    nome varchar (400) not null, 
    email varchar (400) not null, 
    senha varchar (400) not null, 
    administradot boolean not null, 
    primary key (RA)); 
     
create table Tentativas ( 
    RA char(10), 
    nome varchar (400),  
    pontos int,  
    ranking int, 
    foreign key (RA) references Usuario (RA) on update set null on delete set null); 

insert into Questao (alternativa1, alternativa2,alternativa3,alternativa4,Pergunta,Resposta,Pontos)  

values ('a', 
    'b', 
    'c', 
    'd', 
    'e?', 
    'R: XXXX', 
    50); 
select * from Questao;
select Pergunta from Questao; 